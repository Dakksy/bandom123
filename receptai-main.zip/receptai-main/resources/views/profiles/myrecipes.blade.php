@extends('adminlte::page')

@section('title', 'Mano receptai')

@section('content_header')
    <h1>Mano receptai ({{ $recipes->count() }})</h1>
@stop

@section('content')
    <div class="container py-3">
        <div class="row">
            @foreach ($recipes as $item)
                <div class="col-md-6 col-lg-4" >
                    <div class="card relative" >
                        <div  style="position: absolute;right:0px;">
                            @if ($item->show == true)
                                <button class="btn btn-sm btn-primary" disabled="disabled">Patvirtintas</button>
                            @else   
                            <button class="btn btn-sm btn-danger" disabled="disabled">Nepatvirtintas</button>
                            @endif
                        </div>
                        <img style="height: 250px;" src="{{ $item->image ? \Storage::url($item->image) : 'https://www.staticwhich.co.uk/static/images/products/no-image/no-image-available.png' }}" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h4 class="card-text"><a href="{{ route('recipes.show', $item) }}">{{ $item->name }}</a></h4>
                          <a class='btn btn-warning' href="{{ route('recipes.edit', $item) }}">Redaguoti</a>
                        </div>
                      </div>
                </div>
            @endforeach
        </div>
    </div>
@stop

