@extends('adminlte::page')

@section('title', 'Maisto planuoklis')

@section('content_header')
    <h1>Planuoklis</h1>
@stop

@section('content')
    @if(Session::has('message'))
    <div class="alert alert-dismissible fade show {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    @endif

    <table class="table table-striped" id="myTable">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Pavadinimas</th>
            <th scope="col">Receptai</th>
            <th scope="col">Komentarai</th>
            {{-- <th scope="col">Saugoti</th> --}}
            <th scope="col">Trinti</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($days as $item)
            <tr>
                <th scope="row">{{ $item->id }}</th>
                <td>{{ $item->day }}</td>
                <td>
                    @foreach ($item->recipes as $recipe)
                    <div class="my-1  form-inline">
                            <a class="bg-info mr-1 p-1" href="{{ route('recipes.show', $recipe) }}">{{ $recipe->name }}</a>
                            <form action="{{ route('planner.remove', $recipe) }}" method="post" class="">
                                @csrf
                                <input type="text" hidden name="day" value="{{ $item->day_number }}">
                                <button class="btn btn-sm btn-outline-danger" type="submit" class="">X</button>
                            </form>
                        </div>
                    @endforeach
                </td>
                <td>
                    <form action="{{ route('planner.add.comment') }}" method="post">
                    @csrf
                    <input type="text" hidden name="day" value="{{ $item->day_number }}">
                    <div class="input-group mb-3 input-group-sm">
                        <input type="text" name="comment" class="form-control" placeholder="komentaras .." value="{{ $item->comments }}" aria-label="comment" aria-describedby="button-addon2">
                        <div class="input-group-append">
                          <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Saugoti</button>
                        </div>
                      </div>
                    
                    </form>
                    
                </td>
                
                <td>
                    <form action="{{ route('planner.destroy', $item) }}" method="post">
                    @csrf
                    @method('delete')
                    <input type="text" hidden name="day" value="{{ $item->day_number }}">
                    <button type="submit" class="btn btn-danger btn-sm ">Trinti</button>
                    </form>
                </td>
              </tr>
            @endforeach
          
          
        </tbody>
      </table>
@stop

@section('plugins.Datatables', true)

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> 
    $('#myTable').DataTable( {
        responsive: true,
        "order": [[ 3, "asc" ]],
        language: {
            "emptyTable": "Lentelėje nėra duomenų",
            "info": "Rodomi įrašai nuo _START_ iki _END_ iš _TOTAL_ įrašų",
            "infoEmpty": "Rodomi įrašai nuo 0 iki 0 iš 0",
            "infoFiltered": "(atrinkta iš _MAX_ įrašų)",
            "infoThousands": " ",
            "lengthMenu": "Rodyti _MENU_ įrašus",
            "loadingRecords": "Įkeliama...",
            "processing": "Apdorojama...",
            "search": "Ieškoti:",
            "thousands": " ",
            "zeroRecords": "Įrašų nerasta",
            "paginate": {
                "first": "Pirmas",
                "previous": "Ankstesnis",
                "next": "Tolimesnis",
                "last": "Paskutinis"
            },
            "searchPlaceholder": "Ieškoti"
        }
    } );
 </script>
@stop