@extends('adminlte::page')

@section('title', 'Komentarai')

@section('content_header')
    <h1>Visi receptai</h1>
@stop

@section('content')
    @if(Session::has('message'))
    <div class="alert alert-dismissible fade show {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    @endif

    <table class="table table-striped" id="myTable">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Receptas</th>
            <th scope="col">Komentaras</th>
            <th scope="col">Įvertinimas</th>
            <th scope="col">Įkeltas</th>
            <th scope="col">Autorius</th>
            <th scope="col">Trinti</th>
          </tr>
        </thead>
        <tbody>
            @foreach ($comments as $item)
            <tr>
                <th scope="row">{{ $item->recipe->id }}</th>
                <td><a href="{{ route('recipes.show', $item->recipe) }}">{{ $item->recipe->name }}</a></td>
                <td>
                    {{ $item->comment }}
                </td>
                <td>
                    @for ($i = 0; $i < $item->rating; $i++)
                    <i class="fas fa-star text-warning"></i>
                    @endfor
                </td>
                <td>{{ $item->created_at->diffForHumans() }}</td>
                <td>{{ $item->user->email }}</td>
                <td>
                    <form action="{{ route('comment.destroy', $item) }}" method="post">
                    @csrf
                    @method('delete')
                    <button type="submit" class="btn btn-danger btn-sm">Trinti</button>
                    </form>
                </td>
              </tr>
            @endforeach
          
          
        </tbody>
      </table>
@stop

@section('plugins.Datatables', true)

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> 
    $('#myTable').DataTable( {
        responsive: true,
        "order": false,
        language: {
            "emptyTable": "Lentelėje nėra duomenų",
            "info": "Rodomi įrašai nuo _START_ iki _END_ iš _TOTAL_ įrašų",
            "infoEmpty": "Rodomi įrašai nuo 0 iki 0 iš 0",
            "infoFiltered": "(atrinkta iš _MAX_ įrašų)",
            "infoThousands": " ",
            "lengthMenu": "Rodyti _MENU_ įrašus",
            "loadingRecords": "Įkeliama...",
            "processing": "Apdorojama...",
            "search": "Ieškoti:",
            "thousands": " ",
            "zeroRecords": "Įrašų nerasta",
            "paginate": {
                "first": "Pirmas",
                "previous": "Ankstesnis",
                "next": "Tolimesnis",
                "last": "Paskutinis"
            },
            "searchPlaceholder": "Ieškoti"
        }
    } );
 </script>
@stop