@extends('adminlte::page')

@section('title', 'Sukurti ingridientą')

@section('content_header')
<h2>Sukurti naują ingridientą:</h2>
@stop

@section('content')




<div class="container py-3">
    @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
    @if(Session::has('message'))
    <div class="alert alert-dismissible fade show {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    @endif

  <form action="{{ route('add.ingredient') }}" method="POST">
      @csrf
      <div class="form-group">
        <label for="name">Pavadinimas</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="...">
      </div>
      
        <button type="submit" class="btn btn-success">Siųsti</button>
    </form>

    <div class="py-3 row">
        @foreach ($ingredients as $item)
            <div class="col-4 col-lg-3 my-1">
                <form action="{{ route('ingredient.destroy', $item) }}" method="post">
                @csrf
                @method('delete')
                <button type="submit" class="btn btn-sm btn-danger mr-2">X</button>
                {{ $item->name }} 
                
                </form>
                
            </div>
        @endforeach
    </div>

</div>


@stop

