@extends('adminlte::page')

@section('title', 'Redaguoti')

@section('content_header')
<h2>Redaguoti receptą:</h2>
@stop

@section('content')
<div class="container py-3">
  @if ($errors->any())
    <div class="alert alert-danger">
        Ištaisykite žemiau esančias klaidas
    </div>
@endif
@if(Session::has('message'))
    <div class="alert alert-dismissible fade show {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    @endif

  <form action="{{ route('recipes.update', $recipe) }}" method="POST" enctype="multipart/form-data" enctype="multipart/form-data">
      @method('PUT')
      @csrf
      <div class="form-group">
        <label for="name">Pavadinimas <span class="text-danger">*</span></label>
        <input type="text" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}" id="name" name="name" value="{{ $recipe->name }}">
        <div id="nameFeedback" class="invalid-feedback">
          {{ $errors->first('name') }}
        </div>
      </div>
        <div class="form-group">
          <label for="description">Aprašymas</label>
          <textarea class="form-control {{ $errors->has('description') ? 'is-invalid' : '' }}" id="description" name="description" rows="3">{{ $recipe->description }}</textarea>
          <div id="descriptionFeedback" class="invalid-feedback">
            {{ $errors->first('description') }}
          </div>
        </div>

        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="time">Paruošimo laikas (min.):</label>
          </div>
          <select class="custom-select" id="time" name="time">
            
            @for ($i = 5; $i < 180; $i+=5)
              <option value="{{ $i }}" {{ $recipe->time == $i ? 'selected' :'' }}>{{ $i }}</option>
            @endfor
          </select>
        </div>


        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="cook_time">Kepimo laikas (min.):</label>
          </div>
          <select class="custom-select" id="cook_time" name="cook_time">
            <option selected disabled>Pasirinkti ...</option>
            @for ($i = 5; $i < 180; $i+=5)
            <option value="{{ $i }}" {{ $recipe->cook_time == $i ? 'selected' :'' }}>{{ $i }}</option>
            @endfor
          </select>
        </div>

        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <label class="input-group-text" for="calories">Kalorijos (kcal.):</label>
          </div>
          <select class="custom-select" id="calories" name="calories">
            <option selected disabled>Pasirinkti ...</option>
            @for ($i = 5; $i < 2000; $i+=5)
            <option value="{{ $i }}" {{ $recipe->calories == $i ? 'selected' :'' }}>{{ $i }}</option>
            @endfor
          </select>
        </div>

        <div class="form-group">
          <label for="instructions">Instrukcijos: <span class="text-danger">*</span></label>
          <textarea class="form-control {{ $errors->has('instructions') ? 'is-invalid' : '' }}" id="instructions" name="instructions" rows="3">{{ $recipe->instructions }}</textarea>
          <div id="instructionsFeedback" class="invalid-feedback">
            {{ $errors->first('instructions') }}
          </div>
        </div>

        @livewire('recipes.form-edit', ['recipe' => $recipe])
        
       

        @if ($recipe->image)
        <div class="my-3">
          <h5>Sena nuotrauka:</h5>
          <img style="width: 300px;" src="{{ \Storage::url($recipe->image) }}" alt="">
      </div>
        @endif
        <div class="custom-file my-3">
          <input type="file" class="custom-file-input {{ $errors->has('file') ? 'is-invalid' : '' }}" name="file" id="file">
          <label class="custom-file-label" for="file">Pridėti naują nuotrauką</label>
          <div id="fileFeedback" class="invalid-feedback">
            {{ $errors->first('file') }}
          </div>
        </div>

        @if (Auth::check() && Auth::user()->admin == true)
        <div class="form-group">
          <label for="show">Ar receptas matomas?</label>
          <select class="form-control" id="show" name="show">
            <option {{ $recipe->show ? 'selected' : '' }} value="1">Rodomas</option>
            <option {{ !$recipe->show ? 'selected' : '' }} value="0">Paslėptas</option>
          </select>
        </div>
        @endif
        

        <button type="submit" class="btn btn-success">Siųsti</button>
    </form>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>

<script>
    
  $('#description').summernote({
    placeholder: 'Recepto aprašymas ..',
    tabsize: 2,
    height: 120,
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'underline', 'clear']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['table', ['table']],
      ['insert', ['link', 'picture', 'video']],
      ['view', ['fullscreen', 'codeview', 'help']]
    ]
  });

  $('#instructions').summernote({
    placeholder: 'Recepto instrukcija 1,2,3 .. ',
    tabsize: 2,
    height: 120,
    toolbar: [
      ['style', ['style']],
      ['font', ['bold', 'underline', 'clear']],
      ['color', ['color']],
      ['para', ['ul', 'ol', 'paragraph']],
      ['table', ['table']],
      ['insert', ['link', 'picture', 'video']],
      ['view', ['fullscreen', 'codeview', 'help']]
    ]
  });
</script>
@stop

