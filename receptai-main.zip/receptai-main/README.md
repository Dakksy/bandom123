## Receptai

- [x] Paieška pagal turimus produktus (dalinai)
- [x] Recepto siūlymas(user)+pridėjimas/atmetimas(admin)
- [x] Maisto planuoklis pridedant receptus iš sąrašo (dalinai)
- [x] Recepto išsaugojimas
- [x] Prisijungimas
- [ ] Recepto įvertinimas+komentaras;


## Konfiguracija (orientacinė)
1. PHP >=php8
2. npm = 6.14.12
3. node = v14.16.1

## Instrukcija
1. Jei dirbate su Windows, bet neturite susikūrę wamp ar kitokios php aplinkos, rekomenduoju atsisiųsti https://laragon.org/download/

2. Atsidarome laragon terminalą ir nuėjus į /www folderį,  atsisiųsti projektą:
`
git clone https://github.com/emilisz/receptai
`

3. Įeiname į nukopijuoto projekto aplanką:
`
cd receptai
`

4. Įrašome composer dependencies:
`
composer install
`

5. Įrašome npm dependencies:
`
npm install 
`

6. Kopijuojame .env.example failiuką:
`
cp .env.example .env
`

7. Nukopijuotame .env faile pakeiciame duomenu dazes prisijungimo duomenis pagal savo:
```
DB_CONNECTION=mysql          
DB_HOST=127.0.0.1            
DB_PORT=3306                 
DB_DATABASE=receptai     
DB_USERNAME=root             
DB_PASSWORD=         
```


8. Sugeneruojame aplikacijos unikalų raktą:
`
php artisan key:generate
`

9. Migruojame duomenų bazę ir ją 'seedinam' su pradiniais duomenimis:
`
php artisan migrate --seed
`

10. Sukuriame 'symlink', kad galėtume įkelti nuotraukas:
`
php artisan storage:link
`

11. Prisijungimo admin duomenys:
email: admin@email.com
password: password

12. Sukompiliuojame css ir js failus (jeigu stilius išsimėtęs):
`
npm run dev 
`
(arba viska minimalizuot: )
`
npm run prod 
`

Jeigu projektas laragon neranda, galima tiesiog terminale ivesti sią komandą: 
```
php artisan serve
```

