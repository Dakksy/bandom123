<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class IngredientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            'pienas',
            'sviestas',
            'grietinė',
            'kiaušinis',
            'sūris',
            "svogūnas",
            "česnakas",
            "pomidoras",
            "salieras",
            "bulvė",
            "morka",
            "juodas pipiras",
        ];
        foreach($items as $item){
            DB::table('ingredients')->insert([
                'name' => $item
            ]);
        }
    }
}
