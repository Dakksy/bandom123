<?php

namespace Database\Factories;

use App\Models\Recipe;
use Illuminate\Database\Eloquent\Factories\Factory;

class RecipeFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Recipe::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $this->faker->addProvider(new \FakerRestaurant\Provider\en_US\Restaurant($this->faker));
        $show = false;

        return [
            'name' => $this->faker->foodName(),
            'short_description' => $this->faker->realText($maxNbChars = 100, $indexSize = 2),
            'description' => $this->faker->realText($maxNbChars = 800, $indexSize = 2),
            'cook_time' => $this->faker->numberBetween($min = 5, $max = 10),
            'time' => $this->faker->numberBetween($min = 10, $max = 90),
            'instructions' => $this->faker->realText($maxNbChars = 200, $indexSize = 2),
            // $table->string('course')->nullable();
            // $table->string('cuisine')->nullable();
            // $table->longText('keywords')->nullable();
            // $table->bigInteger('calories')->nullable();
            // $table->longText('instructions')->nullable();
            'show' => true
        ];
    }
    
}
