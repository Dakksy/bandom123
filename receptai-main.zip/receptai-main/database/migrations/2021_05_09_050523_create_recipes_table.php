<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRecipesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('recipes', function (Blueprint $table) {
            $table->id();
            $table->longText('name');
            $table->longText('short_description')->nullable();
            $table->longText('description')->nullable();
            $table->bigInteger('cook_time')->nullable();
            $table->bigInteger('time')->nullable();
            $table->string('course')->nullable();
            $table->string('cuisine')->nullable();
            $table->longText('keywords')->nullable();
            $table->bigInteger('calories')->nullable();
            $table->longText('instructions')->nullable();
            $table->boolean('show')->default(true);
            $table->string('image')->nullable();
            $table->integer('user_id')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('recipes');
    }
}
