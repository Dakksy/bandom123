<?php

namespace App\Http\Controllers;

use App\Models\Recipe;
use App\Models\Ingredient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Day;
use Illuminate\Support\Facades\Auth;

class RecipeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['index','show']);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('welcome');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('recipes.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|max:155',
            'description' => 'max:10575',
            'time' => '',
            'cook_time' => '',
            'course' => 'max:75',
            'cuisine' => 'max:75',
            'calories' => '',
            'instructions' => 'required|max:10575',
            'ingredients' => 'required',
            'file' => 'image'
        ]);

        $recipe = Recipe::create($validated);

        $recipe->ingredients()->sync($request->ingredients);
        $recipe->update(['user_id' => Auth::id()]);

        if($request->has('file')){
            $path = $request->file('file')->store('public/recipes');
            $recipe->update(['image' => $path]);
        };

        if (Auth::user()->admin == true) {
           $recipe->update(['show' => true]);
           session()->flash('message', 'Receptas įkeltas');
        } else {
            $recipe->update(['show' => false]);
            session()->flash('message', 'Receptas įkeltas ir laukia administratoriaus peržiūros');
        }

        
        return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Recipe  $recipe
     * @return \Illuminate\Http\Response
     */
    public function show(Recipe $recipe)
    {
        // $recipe = $recipe->with('comments')->get();
        // dd($recipe);
        $days = Day::where('user_id', Auth::id())->get();
        return view('recipes.show', compact('recipe','days'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Recipe  $recipe
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, Recipe $recipe)
    {
        if ($request->user()->cannot('update', $recipe)) {
            abort(403);
        }

        // $ingredients = Ingredient::all();
        return view('recipes.edit', compact('recipe'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Recipe  $recipe
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Recipe $recipe)
    {
        if ($request->user()->cannot('update', $recipe)) {
            abort(403);
        }

        $validated = $request->validate([
            'name' => 'required|max:155',
            'description' => 'max:10575',
            'time' => '',
            'cook_time' => '',
            'course' => 'max:75',
            'cuisine' => 'max:75',
            'calories' => '',
            'instructions' => 'required|max:10575',
            'ingredients' => 'required',
            'file' => 'image'
        ]);

        $recipe->update($validated);

        $recipe->ingredients()->sync($request->ingredients);
        

        if($request->has('file')){
            Storage::delete($recipe->file);
            $path = $request->file('file')->store('public/recipes');
            $recipe->update(['image' => $path]);
        }

        if (!Auth::user()->admin) {
            $recipe->update(['show' => false]);
            return redirect()->back()->with('message','Receptas atnaujintas ir bus rodomas kai patvirtins administratorius');
        } else {
            return redirect()->back()->with('message','Receptas atnaujintas');
        }

        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Recipe  $recipe
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Recipe $recipe)
    {
        if ($request->user()->cannot('delete', $recipe)) {
            abort(403);
        }

        if($recipe->image){
            Storage::delete($recipe->image);
        }
 
        $recipe->delete();
        return back()->with('message','Receptas ištrintas');
    }
}
