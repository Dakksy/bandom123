<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\Recipe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommentController extends Controller
{
   
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, Recipe $recipe)
    {
        $validated = $request->validate([
            'comment' => 'max:375',
            'rating' => 'required',
        ]);


        if (Auth::check()) {
            $comment = new Comment();
            $comment->comment = $request->comment;
            $comment->recipe_id = $recipe->id;
            $comment->user_id = Auth::id();
            $comment->rating = $request->rating;
            $comment->save();
            return back()->with('message','Komentaras pridėtas');
        } else {
            return back()->with('message','Turite prisijungti norėdami komentuoti');
        }
        
        // Comment::create($request->all());
        
    }

   
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Comment $comment)
    {
        if ($request->user()->cannot('delete', $comment)) {
            abort(403);
        }

        $comment->delete();
        return back()->with('message','Komentaras ištrintas');
    } 
}
