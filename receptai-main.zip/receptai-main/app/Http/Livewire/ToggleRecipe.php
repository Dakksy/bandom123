<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ToggleRecipe extends Component
{
    public $recipe;

    public function render()
    {
        return view('livewire.toggle-recipe');
    }

    public function toggleShow()
    {
        $this->recipe->update(['show' => !$this->recipe->show]);
    }
}
