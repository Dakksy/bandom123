<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Recipe extends Model
{
    use \Conner\Likeable\Likeable;
    use HasFactory;
    protected $table = 'recipes';

    protected $fillable = ['name', 'description', 'short_description','instructions','cook_time','time','course','cuisine','keywords','calories','image','show','user_id'];

   

    public function ingredients()
    {
        return $this->belongsToMany(Ingredient::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function days()
    {
        return $this->belongsToMany(Day::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class)->orderBy('created_at','desc');
    }
}
